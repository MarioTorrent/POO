import tkinter as tk

def create_multicolor_arc(canvas, x, y, radius, start_angle, end_angle, colors):
    for i, color in enumerate(colors):
        arc = canvas.create_arc(x - radius, y - radius, x + radius, y + radius,start=start_angle, extent=end_angle - start_angle,outline=color, width=2)
        start_angle = end_angle
        if i < len(colors) - 1:
            end_angle += (end_angle - start_angle) / (len(colors) - 1)

root = tk.Tk()
canvas = tk.Canvas(root, width=400, height=400)
canvas.pack()

# Coordenadas del centro del arco
x, y = 200, 200
radius = 100
start_angle = 0
end_angle = 180

# Colores para el borde multicolor
colors = ["red", "green", "blue", "yellow"]

create_multicolor_arc(canvas, x, y, radius, start_angle, end_angle, colors)

root.mainloop()





