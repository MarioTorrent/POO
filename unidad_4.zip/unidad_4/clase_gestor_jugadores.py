from clase_jugador import jugador
class gestor_jugadores():
    __lista:list
    def __init__(self):
        self.__lista=[]
    def agregar_jugador(self,nom,puntos,fecha,hora):
        xjugador=jugador(nom,puntos,fecha,hora)
        self.ordenar()
    def ordenar(self):
        self.__lista.sort()